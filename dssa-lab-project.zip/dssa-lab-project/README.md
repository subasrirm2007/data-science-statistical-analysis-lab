# Data Science and Statistical Analysis Lab Project (CGI1242)

**Name:** R M Suba sri  
**Register No:** 250381120522055  
**Course:** CGI1242 Data Science and Statistical Analysis Laboratory, B.Tech Information Technology  
**College:** K. Ramakrishnan College of Technology (Autonomous), Samayapuram, Trichy

## Objective
To apply data science tools and statistical methods to small datasets: preparing data, exploring it, building simple models and interpreting the results.

## Project structure
```
code/        Python scripts for Experiments 2 to 6
datasets/    CSV files created and read by the scripts (Exp. 5)
outputs/     Text output of each script, figures, and the combined PDF
README.md
requirements.txt
```

## Scripts
| File | What it does |
|------|--------------|
| `code/exp2.py` | NumPy, Pandas, SciPy (t-test), Statsmodels (OLS) and Matplotlib basics |
| `code/exp3.py` | NumPy arrays: arange, random, empty, zeros, ones, structured array |
| `code/exp4.py` | Pandas DataFrames from CSV, NumPy stacking, add/remove/update rows and columns |
| `code/exp5.py` | Descriptive analysis: CSV read/write, correlation matrices, histograms |
| `code/exp6.py` | Univariate analysis and simple vs multiple linear regression with MSE |

Experiment 1 (Excel to CSV, WEKA classification, visualisation and normalisation) was done with GUI tools, so it has no script.

## Dataset details
- **Property sales** (`datasets/property_sales.csv`): 12 records with locality, area (sq ft), bedrooms, age (years) and sale price.
- **Student performance** (`datasets/student_performance.csv`): 12 records with study hours, attendance, previous score and final score.
- **House price** and **Medical cost** (Exp. 6): 15 records each, defined inside `code/exp6.py`.
- **Property CSV** (Exp. 4): 5 records, defined inside `code/exp4.py`.

All datasets are small, hand-made samples used to demonstrate the methods.

## How to run
```
pip install -r requirements.txt
python code/exp2.py
python code/exp3.py
python code/exp4.py
python code/exp5.py   # writes the CSV files in the current folder
python code/exp6.py
```

## Key findings
- Property sale price is strongly correlated with area (about 0.99) and negatively with property age (-0.84).
- Student final score is strongly correlated with previous score, attendance and study hours (all about 0.99).
- Multiple regression gave a lower MSE than simple regression on both datasets (House price: 19.41 to 11.48; Medical cost: about 256.5 million to 5.84 million). The Smoker variable drove most of the Medical cost improvement.

## Limitations
The datasets are small, so the results demonstrate the methods and are not reliable real-world estimates.
