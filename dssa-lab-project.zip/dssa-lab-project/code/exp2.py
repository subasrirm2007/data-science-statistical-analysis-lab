# Import required libraries
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
import matplotlib.pyplot as plt

# 1. NumPy: Numerical Computing
# Create two arrays
x = np.array([2, 4, 6, 8, 10])
y = np.array([12, 14, 16, 18, 20])

# Perform operations
total = x + y
average_x = np.mean(x)
standard_deviation_y = np.std(y)

print("NumPy Operations:")
print("Sum of arrays x and y:", total)
print("Mean of array x:", average_x)
print("Standard deviation of array y:", standard_deviation_y)
print()

# 2. Pandas: Data Manipulation and Analysis
# Create a DataFrame
data = {
    'Age': [21, 24, 27, 29, 32],
    'Weight': [60, 68, 75, 80, 85],
    'Height': [160, 168, 172, 178, 182]
}
table = pd.DataFrame(data)

# Perform DataFrame operations
average_age = table['Age'].mean()
median_weight = table['Weight'].median()
mode_height = stats.mode(table['Height'], keepdims=True)[0][0]

print("Pandas Operations:")
print("Average age:", average_age)
print("Median weight:", median_weight)
print("Mode height:", mode_height)
print()

# 3. SciPy: Scientific and Statistical Computing
# Perform an independent t-test
t_value, p_value = stats.ttest_ind(x, y)

print("SciPy Operations:")
print("T-statistic:", t_value)
print("P-value:", p_value)
print()

# 4. Statsmodels: Statistical Modeling
# Independent variables
X = sm.add_constant(table[['Age', 'Weight']])
Y = table['Height']

# Create and fit OLS regression model
regression = sm.OLS(Y, X)
result = regression.fit()

print("Statsmodels OLS Regression Results:")
print(result.summary())
print()

# 5. Matplotlib: Data Visualization
# Create scatter plot
plt.scatter(table['Age'], table['Height'])
plt.xlabel('Age')
plt.ylabel('Height')
plt.title('Age vs Height')
plt.show()
