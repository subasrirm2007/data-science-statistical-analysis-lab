import pandas as pd
import numpy as np
from io import StringIO

# Contents of Property.csv (no header row)
data = """201,Anna Nagar,1200,6500000,Apartment
202,Velachery,950,4800000,Apartment
203,T Nagar,1800,12500000,Villa
204,Adyar,1500,9800000,Independent House
205,Tambaram,800,3500000,Plot"""

# Part A: Loading CSV file
df = pd.read_csv(
    StringIO(data),
    header=None,
    names=['Property_ID', 'Locality', 'Area_sqft',
           'Price', 'Property_Type']
)

print("PART A: Basic Information")
df.info()

print("\nFirst 5 rows:")
print(df.head())

print("\nStatistical Summary:")
print(df.describe())

# Part B: Finding Maximum and Minimum
arr = np.array([6500000, 4800000, 12500000, 9800000, 3500000])

print("\nPART B: Maximum and Minimum")
print("Maximum Property Price:", np.max(arr))
print("Minimum Property Price:", np.min(arr))

# Part C: Adding Rows and Columns in NumPy
arr_2d = arr.reshape(-1, 1)
new_rows = np.array([[5200000], [7800000], [15000000]])
arr_with_new_rows = np.vstack([arr_2d, new_rows])

print("\nPART C: NumPy Array with New Rows")
print(arr_with_new_rows)

new_column = np.array(
    [1200, 950, 1800, 1500, 800, 1000, 1350, 2200]
).reshape(-1, 1)
arr_with_new_column = np.hstack([arr_with_new_rows, new_column])

print("\nNumPy Array with New Column")
print(arr_with_new_column)

# Part D: Adding, Removing and Updating using Pandas
# 1. Add a new row
new_row_df = pd.DataFrame({
    'Property_ID': [206],
    'Locality': ['Mylapore'],
    'Area_sqft': [1100],
    'Price': [7200000],
    'Property_Type': ['Apartment']
})
df = pd.concat([df, new_row_df], ignore_index=True)
print("\nPART D: DataFrame After Adding a New Row")
print(df)

# 2. Remove a column
df = df.drop(columns=['Property_Type'])
print("\nDataFrame After Removing Property_Type")
print(df)

# 3. Add a new column
df['Registration_Fee'] = (df['Price'] * 0.07).astype(int)
print("\nDataFrame After Adding Registration_Fee")
print(df)

# 4. Update a specific cell using loc[]
df.loc[0, 'Price'] = 6800000
print("\nDataFrame After Updating Price")
print(df)
