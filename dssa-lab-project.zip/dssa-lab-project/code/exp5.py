import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Part A: Dataset 1 - Property Sales
property_data = {
    'Locality': [
        'Anna Nagar', 'Velachery', 'T Nagar', 'Adyar',
        'Tambaram', 'Mylapore', 'Porur', 'Guindy',
        'Perungudi', 'Besant Nagar', 'Kilpauk', 'Thiruvanmiyur'
    ],
    'AreaSqft': [1200, 950, 1800, 1500, 800, 1100, 1000, 1350, 900, 1650, 1400, 1250],
    'Bedrooms': [3, 2, 4, 3, 2, 2, 2, 3, 2, 4, 3, 3],
    'AgeYears': [5, 8, 3, 6, 12, 9, 7, 4, 10, 2, 6, 5],
    'SalePrice': [
        6500000, 4800000, 12500000, 9800000, 3500000, 7200000,
        4600000, 8900000, 4100000, 11800000, 8700000, 7400000
    ]
}

property_df = pd.DataFrame(property_data)

# Save and read CSV file
property_df.to_csv('property_sales.csv', index=False)
property_df = pd.read_csv('property_sales.csv')

print("PROPERTY SALES DATAFRAME:")
print(property_df)

# Correlation matrix (numeric columns only)
property_corr = property_df.corr(numeric_only=True)
print("\nCORRELATION MATRIX - PROPERTY SALES:")
print(property_corr)

# Histograms
property_df.hist(figsize=(10, 8), bins=5)
plt.suptitle('Histograms of Property Sales Dataset')
plt.tight_layout()
plt.show()

# Part B: Dataset 2 - Student Performance
student_data = {
    'StudentName': [
        'Arjun', 'Meena', 'Karthik', 'Divya',
        'Suresh', 'Lakshmi', 'Vignesh', 'Priya',
        'Naveen', 'Sneha', 'Ramesh', 'Kavya'
    ],
    'StudyHours': [2, 5, 3, 6, 1, 4, 7, 5, 2, 6, 3, 4],
    'Attendance': [70, 92, 80, 95, 60, 85, 98, 90, 72, 94, 78, 88],
    'PreviousScore': [55, 78, 62, 85, 48, 70, 90, 74, 58, 82, 65, 72],
    'FinalScore': [58, 82, 66, 89, 45, 74, 94, 80, 60, 88, 68, 77]
}

student_df = pd.DataFrame(student_data)

# Save and read CSV file
student_df.to_csv('student_performance.csv', index=False)
student_df = pd.read_csv('student_performance.csv')

print("\nSTUDENT PERFORMANCE DATAFRAME:")
print(student_df)

# Correlation matrix (numeric columns only)
student_corr = student_df.corr(numeric_only=True)
print("\nCORRELATION MATRIX - STUDENT PERFORMANCE:")
print(student_corr)

# Histograms
student_df.hist(figsize=(10, 8), bins=5)
plt.suptitle('Histograms of Student Performance Dataset')
plt.tight_layout()
plt.show()
