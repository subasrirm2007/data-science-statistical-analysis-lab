import numpy as np

# a. Create arrays using different methods
# Using arange()
array_arange = np.arange(5, 15)
print("Array using arange():")
print(array_arange)

# Using random.rand()
array_random = np.random.rand(2, 3)
print("\nArray using random.rand():")
print(array_random)

# Using empty()
array_empty = np.empty((2, 2))
print("\nArray using empty():")
print(array_empty)

# b. Create arrays filled with zeros and ones
array_zeros = np.zeros((2, 3))
print("\nArray filled with zeros:")
print(array_zeros)

array_ones = np.ones((2, 3))
print("\nArray filled with ones:")
print(array_ones)

# c. Create Employee Database
employee_dtype = np.dtype([
    ('ID', 'i4'),
    ('Name', 'U10'),
    ('Age', 'i4'),
    ('Salary', 'f4'),
    ('Grade', 'U2')
])

employees = np.array([
    (201, 'John', 25, 45000.0, 'B'),
    (202, 'Mary', 28, 52000.0, 'A'),
    (203, 'David', 23, 38000.0, 'C'),
    (204, 'Sarah', 30, 60000.0, 'A'),
    (205, 'James', 26, 48000.0, 'B')
], dtype=employee_dtype)

print("\nEmployee Database:")
print(employees)

# Select only numeric columns
numeric_employees = employees[['ID', 'Age', 'Salary']]
print("\nNumeric Employee Database:")
print(numeric_employees)

# d. Find row numbers where Salary is greater than 45000
rows_with_high_salary = np.where(numeric_employees['Salary'] > 45000)[0]
print("\nRow numbers with Salary > 45000:")
print(rows_with_high_salary)
