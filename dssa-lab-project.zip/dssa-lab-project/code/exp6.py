import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# Dataset 1: House Price
house_df = pd.DataFrame({
    'Area_sqft': [650, 800, 950, 1100, 1200, 1350, 1500, 1650,
                  1800, 2000, 2200, 2400, 900, 1250, 1700],
    'Bedrooms': [1, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 5, 2, 3, 4],
    'Age': [12, 10, 8, 6, 9, 4, 7, 3, 5, 2, 6, 1, 15, 11, 8],
    'Price': [38, 52, 60, 72, 76, 92, 96, 110, 125, 142,
              150, 170, 54, 80, 115]
})

# Dataset 2: Medical Cost
medical_df = pd.DataFrame({
    'Age': [19, 25, 28, 32, 32, 37, 41, 41, 45, 50, 52, 56, 60, 23, 28],
    'BMI': [27.9, 22.7, 33.0, 28.9, 30.1, 25.5, 31.2, 26.8,
            35.4, 29.6, 33.7, 28.1, 32.4, 24.3, 36.2],
    'Children': [0, 1, 3, 0, 2, 1, 2, 0, 3, 1, 0, 2, 1, 0, 1],
    'Smoker': [1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0],
    'Charges': [16800, 4200, 5400, 5100, 22500, 6900, 24800,
                7300, 19500, 10200, 29800, 12400, 31500, 3400, 6200]
})

# Univariate Analysis
def univariate_analysis(df, column):
    freq = df[column].value_counts().sort_index()
    mean = df[column].mean()
    median = df[column].median()
    mode = df[column].mode()[0]
    std = df[column].std()
    return freq, mean, median, mode, std

# Simple and Multiple Linear Regression
def regression_analysis(df, simple_feature, multi_features, target):
    X = df[[simple_feature]]
    y = df[target]

    # Simple Linear Regression
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    lin_reg = LinearRegression()
    lin_reg.fit(X_train, y_train)
    y_pred = lin_reg.predict(X_test)
    mse_simple = mean_squared_error(y_test, y_pred)

    print("\nSimple Linear Regression")
    print("Coefficient:", lin_reg.coef_[0])
    print("Intercept:", lin_reg.intercept_)
    print("Mean Squared Error:", mse_simple)

    # Multiple Linear Regression
    Xm = df[multi_features]
    Xm_train, Xm_test, ym_train, ym_test = train_test_split(
        Xm, y, test_size=0.2, random_state=42
    )
    multi_reg = LinearRegression()
    multi_reg.fit(Xm_train, ym_train)
    ym_pred = multi_reg.predict(Xm_test)
    mse_multi = mean_squared_error(ym_test, ym_pred)

    print("\nMultiple Linear Regression")
    print("Coefficients:", multi_reg.coef_)
    print("Intercept:", multi_reg.intercept_)
    print("Mean Squared Error:", mse_multi)

    return mse_simple, mse_multi

# Run Analysis
def run(name, df, uni_col, simple_feature, multi_features, target):
    print("\n" + "=" * 50)
    print(name)
    print("=" * 50)

    print("\nDataset:")
    print(df.head())

    freq, mean, median, mode, std = univariate_analysis(df, uni_col)
    print(f"\nUnivariate Analysis for {uni_col}:")
    print("Frequency:")
    print(freq)
    print("Mean:", mean)
    print("Median:", median)
    print("Mode:", mode)
    print("Standard Deviation:", std)

    return regression_analysis(df, simple_feature, multi_features, target)

# House Price Analysis
h = run("House Price Dataset", house_df,
        'Bedrooms', 'Area_sqft',
        ['Area_sqft', 'Bedrooms', 'Age'], 'Price')

# Medical Cost Analysis
m = run("Medical Cost Dataset", medical_df,
        'Age', 'Age',
        ['Age', 'BMI', 'Children', 'Smoker'], 'Charges')

# Compare Mean Squared Errors
print("\n" + "=" * 50)
print("MSE Comparison")
print("=" * 50)
comp = pd.DataFrame(
    {
        'Simple MSE': [h[0], m[0]],
        'Multiple MSE': [h[1], m[1]]
    },
    index=['House Price', 'Medical Cost']
)
print(comp)
